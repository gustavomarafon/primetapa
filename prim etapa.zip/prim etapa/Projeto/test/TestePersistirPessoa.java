

import java.util.Calendar;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import modelo.Departamento;
import modelo.Projeto;
import modelo.Tipo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class TestePersistirPessoa {
    
    EntityManagerFactory emf;
    EntityManager em;
    
    public TestePersistirPessoa() {
    }
    
  
    
    @Test
    public void teste(){
        
        Projeto p = new Projeto();
        p.setNome("Revitalização");
        
        p.setNome("Governo Federal");
        p.setDescricao("teste");
        p.setAtivo(Boolean.TRUE);
        p.setValor(25000.00);
        p.setDepartamento(em.find(Departamento.class, 2));
        p.setTipo(em.find(Tipo.class, 1));
        p.setDatafim(Calendar.getInstance());
        p.setDatainicio(Calendar.getInstance());
  
        em.getTransaction().begin();
        em.persist(p);
        em.getTransaction().commit();
    }
    
      @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("ProjetoPU");
        em = emf.createEntityManager();        
    }
    
    
    @After
    public void tearDown() {
        em.close();
        emf.close();
    }
    
}
