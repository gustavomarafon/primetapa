

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import modelo.Departamento;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class TestePersistirDepartamento {
    
    EntityManagerFactory emf;
    EntityManager em;
    
    public TestePersistirDepartamento() {
    }
    
  
    
    @Test
    public void teste(){
        
        Departamento p = new Departamento();
        p.setNome("Alfa");
        p.setResposavel("Josias");
        p.setTelefone("543333-3333");
        
        em.getTransaction().begin();
        em.persist(p);
        em.getTransaction().commit();
    }
    
      @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("ProjetoPU");
        em = emf.createEntityManager();        
    }
    
    
    @After
    public void tearDown() {
        em.close();
        emf.close();
    }
    
}
