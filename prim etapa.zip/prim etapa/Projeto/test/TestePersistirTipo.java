

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import modelo.Tipo;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class TestePersistirTipo {
    
    EntityManagerFactory emf;
    EntityManager em;
    
    public TestePersistirTipo() {
    }
    
  
    
    @Test
    public void teste(){
        
        Tipo p = new Tipo();
        p.setNome("Revitalização");
        
        em.getTransaction().begin();
        em.persist(p);
        em.getTransaction().commit();
    }
    
      @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("ProjetoPU");
        em = emf.createEntityManager();        
    }
    
    
    @After
    public void tearDown() {
        em.close();
        emf.close();
    }
    
}
