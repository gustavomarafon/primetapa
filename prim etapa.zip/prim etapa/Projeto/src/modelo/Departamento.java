/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author Guto
 */

@Entity
@Table(name = "departamento")
public class Departamento implements Serializable{
   
   
    @Id
    @SequenceGenerator(name = "seq_tipo", sequenceName = "seq_tipo_id", allocationSize = 1)
    @GeneratedValue(generator = "seq_tipo", strategy = GenerationType.SEQUENCE)
    private Integer id;
   
    @NotNull(message = "O nome do tipo deve ser informado")
    @NotBlank(message = "O nome do tipo não pode ser em branco")
    @Length(max = 50, message = "O nome do tipo não pode ter mais que {max} caracteres")
    @Column(name = "tipo", nullable = false)
    private String nome;
    @NotNull(message = "O responsavel deve ser informado")
    @NotBlank(message = "O responsavel não pode ser em branco")
    @Length(max = 50, message = "O responsavel não pode ter mais que {max} caracteres")
    @Column(name = "responsavel", nullable = false)
    private String resposavel;
     @NotNull(message = "O telefone deve ser informado")
    @NotBlank(message = "O telefone não pode ser em branco")
    @Length(max = 50, message = "O telefone não pode ter mais que {max} caracteres")
    @Column(name = "telefone", nullable = false)
    private String telefone;
    
    public Departamento() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 71 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Departamento other = (Departamento) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    public String getResposavel() {
        return resposavel;
    }

    public void setResposavel(String resposavel) {
        this.resposavel = resposavel;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
}
