
package controle;

import DAO.DepartamentoDAO;


import java.io.Serializable;
import javax.ejb.EJB;
import javax.inject.Named;

import br.edu.ifsul.util.Util;
import javax.faces.view.ViewScoped;
import modelo.Departamento;


/**
 *
 * @author Telmo
 */
@Named(value = "controleDepartamento")
@ViewScoped
public class ControleDepartamento implements Serializable {

        @EJB
        private DepartamentoDAO dao;
        
        private Departamento objeto;

        public ControleDepartamento(){

        }

        public String listar(){
                return "/privado/departamento/cruddepartamento?faces-redirect=true";
        }

        public void novo(){
                objeto = new Departamento();        
        }



        public void alterar(Object id){
                try {
                        objeto = dao.getObjectById(id);            
                } catch (Exception e){
                        Util.mensagemErro("Erro ao recuperar objeto: " + 
                                        Util.getMensagemErro(e));
                } 
        }

        public void excluir(Object id){
                try {
                        objeto = dao.getObjectById(id);
                        dao.remover(objeto);
                        Util.mensagemInformacao("Objeto removido com sucesso!");
                } catch (Exception e){
                        Util.mensagemErro("Erro ao remover objeto: " + 
                                        Util.getMensagemErro(e));
                }
        }

        public void salvar(){
                try {
                        if (objeto.getId() == null){
                                dao.persist(objeto);
                        } else {
                                dao.merge(objeto);
                        }
                        Util.mensagemInformacao("Objeto persistido com sucesso!");            
                } catch(Exception e){
                        Util.mensagemErro("Erro ao persistir objeto: " + 
                                        Util.getMensagemErro(e));
                }
        }

        public DepartamentoDAO getDao() {
        return dao;
        }

        public Departamento getObjeto() {
        return objeto;
        }
    
}
