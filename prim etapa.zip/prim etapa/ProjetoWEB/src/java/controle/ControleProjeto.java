package controle;

import DAO.ProjetoDAO;

import java.io.Serializable;
import javax.ejb.EJB;
import javax.inject.Named;

import br.edu.ifsul.util.Util;
import javax.faces.view.ViewScoped;
import modelo.Projeto;

/**
 *
 * @author Telmo
 */
@Named(value = "controleProjeto")
@ViewScoped
public class ControleProjeto implements Serializable {
    
    @EJB
    private ProjetoDAO dao;

    private Projeto objeto;

    public ControleProjeto(){

    }
    
    public String listar(){
        return "/privado/projeto/crudprojeto?faces-redirect=true";
    }

    public void novo(){
        objeto = new Projeto();      
    }

    public ProjetoDAO getDao() {
        return dao;
    }
    
    
    
    public void alterar(Object id){
                try {
                        setObjeto(dao.getObjectById(id));            
                } catch (Exception e){
                        Util.mensagemErro("Erro ao recuperar objeto: " + 
                                        Util.getMensagemErro(e));
                } 
        }

        public void excluir(Object id){
                try {
                        setObjeto(dao.getObjectById(id));
                        dao.remover(getObjeto());
                        Util.mensagemInformacao("Objeto removido com sucesso!");
                } catch (Exception e){
                        Util.mensagemErro("Erro ao remover objeto: " + 
                                        Util.getMensagemErro(e));
                }
        }

        public void salvar(){
                try {
                        if (getObjeto().getId() == null){
                                dao.persist(getObjeto());
                        } else {
                                dao.merge(getObjeto());
                        }
                        Util.mensagemInformacao("Objeto persistido com sucesso!");            
                } catch(Exception e){
                        Util.mensagemErro("Erro ao persistir objeto: " + 
                                        Util.getMensagemErro(e));
                }
        }

    public Projeto getObjeto() {
        return objeto;
    }

    public void setObjeto(Projeto objeto) {
        this.objeto = objeto;
    }
    
    
}
