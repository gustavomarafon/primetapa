
package DAO; 

import converter.ConverterOrdem;
import javax.ejb.Stateful;

import java.io.Serializable;
import modelo.Departamento;
import modelo.Tipo;

@Stateful
public class DepartamentoDAO extends DAOGenerico<Departamento> implements Serializable {

    public DepartamentoDAO(){
        super(Departamento.class);      
        
        // inicializar as ordenações possiveis        
        listaOrdem.add(new Ordem("id", "ID", "="));
        listaOrdem.add(new Ordem("nome", "Nome", "like"));
        // definir qual a ordenação padrão no caso o segundo elemento da lista (indice 1)
        ordemAtual = listaOrdem.get(0);
        // inicializar o conversor com a lista de ordens
        converterOrdem = new ConverterOrdem(listaOrdem);
    }
}	
