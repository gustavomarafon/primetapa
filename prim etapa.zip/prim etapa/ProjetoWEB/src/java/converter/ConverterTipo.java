
package converter;

import DAO.TipoDAO;

import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Named;
import modelo.Tipo;

/**
 *
 * @author Telmo
 */

@Named(value = "converterTipo") 
@RequestScoped
public class ConverterTipo implements Serializable, Converter {
    
    @EJB
    private TipoDAO dao;
    
    public ConverterTipo(){
        
    }
    
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String string) {
        
        if(string == null || string.equals("Selecione") || string.equals("Selecione um registro")){
            return null;
        }
       
        return  dao.find(Integer.parseInt(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        if (o == null){
            return null;
        }
        Tipo obj = (Tipo) o;
        return obj.getId().toString();
    }
}
