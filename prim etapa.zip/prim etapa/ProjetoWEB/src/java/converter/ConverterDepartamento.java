
package converter;

import DAO.DepartamentoDAO;
import DAO.TipoDAO;

import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Named;
import modelo.Departamento;
import modelo.Tipo;

/**
 *
 * @author Telmo
 */

@Named(value = "converterDepartamento") 
@RequestScoped
public class ConverterDepartamento implements Serializable, Converter {
    
    @EJB
    private DepartamentoDAO dao;
    
    public ConverterDepartamento(){
        
    }
    
    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String string) {
        
        if(string == null || string.equals("Selecione") || string.equals("Selecione um registro")){
            return null;
        }
       
        return  dao.find(Integer.parseInt(string));
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        if (o == null){
            return null;
        }
        Departamento obj = (Departamento) o;
        return obj.getId().toString();
    }
}
